// --------------------------
// Projet4 - Todo list
// --------------------------

const addTask = document.querySelector('#add-task');
const taskContainer = document.querySelector('#task-container');
const inputTask = document.querySelector('#input-task');

// Event Listener pour le bouton + (ajouter une tâche)

addTask.addEventListener('click', () => {
    let task = document.createElement('div'); // Je crée une balise <div>
    task.classList.add('task'); // J'ajoute une classe "task" à ma <div>

    let li = document.createElement('li'); // Je crée une balise <li>
    li.textContent = `${inputTask.value}`; // Je récupère la valeur de l'input
    document.getElementById('input-task').value = "";

    task.appendChild(li); // Cela va rajouter une balise <li> au sein de ma <div>

    let checkBtn = document.createElement('button');
    checkBtn.classList.add('bi', 'bi-check');
    checkBtn.setAttribute('id', 'check-task');

    task.appendChild(checkBtn);

    let deleteBtn = document.createElement('button');
    deleteBtn.classList.add('bi', 'bi-trash3');
    deleteBtn.setAttribute('id', 'delete-task');

    task.appendChild(deleteBtn);

    taskContainer.appendChild(task);

    checkBtn.addEventListener('click', () => {
        li.classList.toggle('strike');
    });

    deleteBtn.addEventListener('click', () => {
        function removeTask() {
            li.parentNode.parentNode.removeChild(task);
     }
     let del = confirm("Êtes-vous sûr de vouloir supprimer?");
     if (del) {
        removeTask();
     } else {
        return false;
     }

    });
});